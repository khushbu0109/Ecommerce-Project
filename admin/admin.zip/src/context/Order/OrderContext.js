import { createContext } from "react";

const OrderCon = createContext();
export default OrderCon;