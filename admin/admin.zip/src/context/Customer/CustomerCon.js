import { createContext } from "react";

const Custcon = createContext();
export default Custcon;