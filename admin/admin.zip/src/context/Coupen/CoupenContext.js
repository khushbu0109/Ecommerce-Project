import { createContext } from "react";

const couponCon = createContext();
export default couponCon;