import { createContext } from "react";

const categoryCon = createContext();
export default categoryCon;