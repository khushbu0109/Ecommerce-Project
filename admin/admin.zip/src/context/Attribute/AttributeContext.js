import { createContext } from "react";

const attributeCon = createContext();
export default attributeCon;