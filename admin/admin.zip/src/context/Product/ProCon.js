import { createContext } from "react";

const ProCon = createContext();
export default ProCon;