import { createContext } from "react";

const LoginCon = createContext();
export default LoginCon;