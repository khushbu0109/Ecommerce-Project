import { createContext } from "react";

const VarCon = createContext();
export default VarCon;