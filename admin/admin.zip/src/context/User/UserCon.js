import { createContext } from "react";

const usercon = createContext();
export default usercon;