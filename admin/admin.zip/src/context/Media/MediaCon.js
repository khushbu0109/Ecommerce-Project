import { createContext } from "react";

const MediaCon = createContext();
export default MediaCon;