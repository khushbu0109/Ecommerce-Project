import React, { useEffect, useState } from "react";
require("dotenv").config();
export default function StockSummary() {
  const host = process.env.REACT_APP_URL;
  const [query, setQuery] = useState("");

  return (<></>)
}