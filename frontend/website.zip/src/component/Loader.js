import React from 'react'

export const Loader = () => {
  return (
    <>
    <div class="preloader">
    <div class="lds-ellipsis">
        <span></span>
        <span></span>
        <span></span>
    </div>
</div>

    </>
  )
}
